

var count=0;


$("h1").text("Play the game");

$(".ghor").click(function(){

count=count+1;
$(this).text(count);


})